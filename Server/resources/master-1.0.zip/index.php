<?php 
require_once __DIR__ . '/src/Test.php';

$test = new Test;

print $test->add(1, 2);
